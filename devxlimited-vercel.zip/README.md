# DEVX LIMITED — static website

Website tiếng Anh thuần HTML và CSS. Không JavaScript, không framework, không cần cài thư viện hoặc chạy build.

## Các file sử dụng

```text
public/
  index.html
  privacy-policy.html
  terms.html
  cookie-policy.html
  contact.html
  style.css
vercel.json
```

Chỉnh nội dung trực tiếp trong các file HTML ở `public/`. Chỉnh giao diện trong `public/style.css`. Mở `public/index.html` bằng trình duyệt để xem ngay. Menu trên điện thoại luôn hiển thị, không cần JavaScript.

`public/` là bản chính để triển khai và chỉnh sửa từ bây giờ. Thư mục `website/` lưu bản cũ; không chạy các script build cũ để cập nhật bản mới.

## Đưa lên Vercel qua GitHub

1. Đưa thư mục `public/` và file `vercel.json` vào thư mục gốc của repository GitHub. Nếu sử dụng file ZIP được cung cấp, giải nén rồi tải các file bên trong lên GitHub; không tải nguyên file ZIP lên repository.
2. Trong Vercel chọn **Add New → Project**, import repository GitHub.
3. Giữ **Root Directory** ở gốc repository. Cấu hình `vercel.json` đã đặt **Framework Preset: Other**, không chạy Build/Install Command và **Output Directory: public**.
4. Chọn **Deploy**. Vercel sẽ cung cấp đường dẫn website sau khi triển khai thành công.

Không đặt Root Directory thành `public`, vì `vercel.json` nằm ở thư mục cha.

## Cách khác: Vercel CLI

Nếu máy đã có Node.js, mở terminal tại thư mục chứa `vercel.json` và chạy:

```powershell
npx vercel --prod
```

Đăng nhập và làm theo hướng dẫn của Vercel. Node.js chỉ phục vụ công cụ triển khai; website không cần Node.js để hoạt động.

## Dùng tên miền riêng

Sau khi deploy, mở **Project → Settings → Domains**, thêm `devxlimited.com`, rồi cấu hình DNS đúng theo thông tin Vercel hiển thị. Giữ nguyên các bản ghi MX/TXT phục vụ email `admin@devxlimited.com`.

## Ghi chú

- Nút liên hệ mở ứng dụng email của khách truy cập và gửi tới `admin@devxlimited.com`; không có backend nhận form.
- Có đủ trang giới thiệu, Privacy Policy, Terms & Conditions, Cookie Policy và Contact.
- Hình điện thoại được dựng bằng HTML/CSS và ghi rõ là minh họa, không phải dự án khách hàng thực tế.
- Chính sách hiện mô tả website công ty. Chính sách riêng của từng mobile app cần dựa trên dữ liệu và SDK thực tế của app.

Tài liệu chính thức: https://vercel.com/docs/builds/configure-a-build và https://vercel.com/docs/project-configuration/vercel-json
